package com.tindrink.demo.rest;

import java.util.Map;

import com.tindrink.demo.entity.Drink;
import com.tindrink.demo.entity.Views.List;

public class DrinkWrapper {
    
    public Drink drinks;

}