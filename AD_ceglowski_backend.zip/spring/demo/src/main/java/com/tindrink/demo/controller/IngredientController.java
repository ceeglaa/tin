package com.tindrink.demo.controller;

import com.tindrink.demo.entity.Ingredient;

public class IngredientController {

    private Ingredient ingredient;

    public IngredientController(Ingredient ingredient){
        this.ingredient = ingredient;
    }

}